<?php
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['error'=>'Method not allowed']); exit; }
$raw=file_get_contents('php://input'); $data=json_decode($raw,true) ?: $_POST;
$name=trim($data['name']??''); $email=trim($data['email']??''); $company=trim($data['company']??''); $message=trim($data['message']??'');
if($name==='' || !filter_var($email,FILTER_VALIDATE_EMAIL) || $message===''){http_response_code(422);echo json_encode(['error'=>'Please provide your name, a valid email address, and a message.']);exit;}
$apiKey=getenv('RESEND_API_KEY');
$to=getenv('CONTACT_TO_EMAIL') ?: 'inspireiqglobal@gmail.com';
$from=getenv('CONTACT_FROM_EMAIL') ?: 'Website <onboarding@resend.dev>';
if(!$apiKey){http_response_code(500);echo json_encode(['error'=>'Email service is not configured yet. Add RESEND_API_KEY in Vercel project settings.']);exit;}
$payload=json_encode(['from'=>$from,'to'=>[$to],'reply_to'=>$email,'subject'=>'New website enquiry from '.$name,'html'=>'<h2>New website enquiry</h2><p><b>Name:</b> '.htmlspecialchars($name).'</p><p><b>Email:</b> '.htmlspecialchars($email).'</p><p><b>Company:</b> '.htmlspecialchars($company ?: 'Not provided').'</p><p><b>Message:</b><br>'.nl2br(htmlspecialchars($message)).'</p>']);
$ch=curl_init('https://api.resend.com/emails');curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$apiKey,'Content-Type: application/json'],CURLOPT_POSTFIELDS=>$payload,CURLOPT_TIMEOUT=>15]);$response=curl_exec($ch);$status=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
if($status<200||$status>=300){http_response_code(502);echo json_encode(['error'=>'The email service rejected the message. Check your Resend settings.']);exit;}
echo json_encode(['ok'=>true]);
